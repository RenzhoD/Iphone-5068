//
//  Servis.swift
//  proyect2
//
//  Created by user195154 on 11/19/21.
//

import Foundation
import Alamofire

struct Servis{
    func getAllServis() {
        let urlString = "https://api.themoviedb.org/3/movie/popular?api_key=176de15e8c8523a92ff640f432966c9c"
        let request = AF.request(urlString)
        
        request.response{ dataResponse in
            
            guard let data = dataResponse.data else {
                print("Error")
                return
            }
            
            let json =  try? JSONSerialization.jsonObject(with: data, options: .allowFragments)
            print(json ?? "No puede leer")
        }
    }
}

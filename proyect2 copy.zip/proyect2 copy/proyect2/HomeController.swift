//
//  HomeController.swift
//  proyect2
//
//  Created by user195154 on 12/10/21.
//

import UIKit

class HomeController:UIViewController{
    
    @IBOutlet weak var itemboton: UIButton!
    @IBOutlet weak var itemButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        itemboton.layer.cornerRadius = 10
        itemButton.layer.cornerRadius = 10
        
    }
}

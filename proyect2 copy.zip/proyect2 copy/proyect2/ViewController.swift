//
//  ViewController.swift
//  proyect2
//
//  Created by user195154 on 10/8/21.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate{
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let servis = Servis()
        servis.getAllServis()
    }
}

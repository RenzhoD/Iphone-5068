import UIKit

class PefilViewController: UIViewController {
    
    
    @IBOutlet weak var imagePerfil: UIImageView!
    
    @IBOutlet weak var emailTextField: UITextField!
    
    @IBOutlet weak var nameTextField: UITextField!
    
    @IBOutlet weak var lastNameTextField: UITextField!
    
    @IBOutlet weak var numberPhoneTextField: UITextField!
    
    @IBOutlet weak var changesButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        nameTextField.layer.borderWidth = 1.0
        nameTextField.layer.cornerRadius = 13.0
        
        lastNameTextField.layer.borderWidth = 1.0
        lastNameTextField.layer.cornerRadius = 13.0
        
        emailTextField.layer.borderWidth = 1.0
        emailTextField.layer.cornerRadius = 13.0
        
        changesButton.backgroundColor = UIColor.init(red: 48/255, green: 173/255, blue: 99/255, alpha: 1)
        changesButton.layer.cornerRadius = 25.0
        changesButton.tintColor = UIColor.black

        
    }
    
}
